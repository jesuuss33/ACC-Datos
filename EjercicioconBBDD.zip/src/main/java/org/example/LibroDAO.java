package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {

    public void insertar(Libro l) throws SQLException {
        String sql = "INSERT INTO libros (titulo, autor, num_ejemplares, editorial, num_paginas, anio_edicion) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getNumEjemplares());
            ps.setString(4, l.getEditorial());
            ps.setInt(5, l.getNumPaginas());
            ps.setInt(6, l.getAnioEdicion());
            ps.executeUpdate();
        }
    }

    public int eliminar(int idLibro) throws SQLException {
        String sql = "DELETE FROM libros WHERE id_libro = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idLibro);
            return ps.executeUpdate();   // nº de filas borradas
        }
    }

    public int modificar(Libro l) throws SQLException {
        String sql = "UPDATE libros SET titulo = ?, autor = ?, num_ejemplares = ?, "
                + "editorial = ?, num_paginas = ?, anio_edicion = ? WHERE id_libro = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getNumEjemplares());
            ps.setString(4, l.getEditorial());
            ps.setInt(5, l.getNumPaginas());
            ps.setInt(6, l.getAnioEdicion());
            ps.setInt(7, l.getIdLibro());   // el WHERE va el último
            return ps.executeUpdate();
        }
    }
    public List<Libro> buscarPorTitulo(String titulo) throws SQLException {
        return buscar("SELECT * FROM libros WHERE LOWER(titulo) LIKE LOWER(?)", titulo);
    }

    public List<Libro> buscarPorAutor(String autor) throws SQLException {
        return buscar("SELECT * FROM libros WHERE LOWER(autor) LIKE LOWER(?)", autor);
    }

    private List<Libro> buscar(String sql, String valor) throws SQLException {
        List<Libro> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + valor + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Libro l = new Libro();
                    l.setIdLibro(rs.getInt("id_libro"));
                    l.setTitulo(rs.getString("titulo"));
                    l.setAutor(rs.getString("autor"));
                    l.setNumEjemplares(rs.getInt("num_ejemplares"));
                    l.setEditorial(rs.getString("editorial"));
                    l.setNumPaginas(rs.getInt("num_paginas"));
                    l.setAnioEdicion(rs.getInt("anio_edicion"));
                    lista.add(l);
                }
            }
        }
        return lista;
    }
}