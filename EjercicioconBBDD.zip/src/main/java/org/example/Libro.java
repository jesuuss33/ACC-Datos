package org.example;

public class Libro {
    private int idLibro;
    private String titulo;
    private String autor;
    private int numEjemplares;
    private String editorial;
    private int numPaginas;
    private int anioEdicion;

    public Libro() {}

    public Libro(String titulo, String autor, int numEjemplares,
                 String editorial, int numPaginas, int anioEdicion) {
        this.titulo = titulo;
        this.autor = autor;
        this.numEjemplares = numEjemplares;
        this.editorial = editorial;
        this.numPaginas = numPaginas;
        this.anioEdicion = anioEdicion;
    }

    public int getIdLibro() { return idLibro; }
    public void setIdLibro(int idLibro) { this.idLibro = idLibro; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }
    public int getNumEjemplares() { return numEjemplares; }
    public void setNumEjemplares(int numEjemplares) { this.numEjemplares = numEjemplares; }
    public String getEditorial() { return editorial; }
    public void setEditorial(String editorial) { this.editorial = editorial; }
    public int getNumPaginas() { return numPaginas; }
    public void setNumPaginas(int numPaginas) { this.numPaginas = numPaginas; }
    public int getAnioEdicion() { return anioEdicion; }
    public void setAnioEdicion(int anioEdicion) { this.anioEdicion = anioEdicion; }

    @Override
    public String toString() {
        return idLibro + " | " + titulo + " | " + autor + " | " + editorial
                + " | ejemplares: " + numEjemplares;
    }
}