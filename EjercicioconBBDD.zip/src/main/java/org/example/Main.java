package org.example;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final LibroDAO libros = new LibroDAO();
    private static final SocioDAO socios = new SocioDAO();
    private static final PrestamoDAO prestamos = new PrestamoDAO();

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerInt("Opción: ");
            try {
                switch (opcion) {
                    case 1 -> altaLibro();
                    case 2 -> System.out.println("Borrados: " + libros.eliminar(leerInt("Id del libro: ")));
                    case 3 -> modificarLibro();
                    case 4 -> altaSocio();
                    case 5 -> System.out.println("Borrados: " + socios.eliminar(leerInt("Id del socio: ")));
                    case 6 -> modificarSocio();
                    case 7 -> libros.buscarPorTitulo(leerTexto("Título: ")).forEach(System.out::println);
                    case 8 -> libros.buscarPorAutor(leerTexto("Autor: ")).forEach(System.out::println);
                    case 9 -> socios.buscarPorNombre(leerTexto("Nombre: ")).forEach(System.out::println);
                    case 10 -> socios.buscarPorApellidos(leerTexto("Apellidos: ")).forEach(System.out::println);
                    case 11 -> prestar();
                    case 12 -> prestamos.librosPrestados().forEach(System.out::println);
                    case 13 -> System.out.println("Libros prestados: "
                            + prestamos.contarPrestamosSocio(leerInt("Id del socio: ")));
                    case 14 -> prestamos.librosVencidos().forEach(System.out::println);
                    case 15 -> prestamos.sociosConRetraso().forEach(System.out::println);
                    case 0 -> System.out.println("Hasta luego");
                    default -> System.out.println("Opción no válida");
                }
            } catch (SQLException e) {
                System.out.println("Error de BD: " + e.getMessage());
            }
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println("\n===== BIBLIOTECA =====");
        System.out.println("1. Alta libro          2. Baja libro        3. Modificar libro");
        System.out.println("4. Alta socio          5. Baja socio        6. Modificar socio");
        System.out.println("7. Buscar libro (título)   8. Buscar libro (autor)");
        System.out.println("9. Buscar socio (nombre)   10. Buscar socio (apellidos)");
        System.out.println("11. Prestar libro");
        System.out.println("12. Libros prestados       13. Nº libros de un socio");
        System.out.println("14. Libros vencidos        15. Socios con retraso");
        System.out.println("0. Salir");
    }

    private static void altaLibro() throws SQLException {
        Libro l = new Libro(leerTexto("Título: "), leerTexto("Autor: "), leerInt("Ejemplares: "),
                leerTexto("Editorial: "), leerInt("Páginas: "), leerInt("Año: "));
        libros.insertar(l);
        System.out.println("Libro dado de alta");
    }

    private static void modificarLibro() throws SQLException {
        Libro l = new Libro();
        l.setIdLibro(leerInt("Id del libro a modificar: "));
        l.setTitulo(leerTexto("Nuevo título: "));
        l.setAutor(leerTexto("Nuevo autor: "));
        l.setNumEjemplares(leerInt("Nuevos ejemplares: "));
        l.setEditorial(leerTexto("Nueva editorial: "));
        l.setNumPaginas(leerInt("Nuevas páginas: "));
        l.setAnioEdicion(leerInt("Nuevo año: "));
        System.out.println("Modificados: " + libros.modificar(l));
    }

    private static void altaSocio() throws SQLException {
        Socio s = new Socio(leerTexto("Nombre: "), leerTexto("Apellidos: "), leerInt("Edad: "),
                leerTexto("Dirección: "), leerTexto("Teléfono: "));
        socios.insertar(s);
        System.out.println("Socio dado de alta");
    }

    private static void modificarSocio() throws SQLException {
        Socio s = new Socio();
        s.setIdSocio(leerInt("Id del socio a modificar: "));
        s.setNombre(leerTexto("Nuevo nombre: "));
        s.setApellidos(leerTexto("Nuevos apellidos: "));
        s.setEdad(leerInt("Nueva edad: "));
        s.setDireccion(leerTexto("Nueva dirección: "));
        s.setTelefono(leerTexto("Nuevo teléfono: "));
        System.out.println("Modificados: " + socios.modificar(s));
    }

    private static void prestar() throws SQLException {
        int idLibro = leerInt("Id del libro: ");
        int idSocio = leerInt("Id del socio: ");
        int dias = leerInt("Días de préstamo: ");
        LocalDate hoy = LocalDate.now();
        boolean ok = prestamos.prestar(idLibro, idSocio, hoy, hoy.plusDays(dias));
        System.out.println(ok ? "Préstamo realizado" : "No quedan ejemplares (o el libro no existe)");
    }

    private static String leerTexto(String msg) {
        System.out.print(msg);
        return sc.nextLine();
    }

    private static int leerInt(String msg) {
        while (true) {
            try {
                return Integer.parseInt(leerTexto(msg).trim());
            } catch (NumberFormatException e) {
                System.out.println("Introduce un número válido");
            }
        }
    }
}