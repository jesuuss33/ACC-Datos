package org.example;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class PrestamoDAO {

    // Devuelve true si se hizo el préstamo, false si no quedan ejemplares
    public boolean prestar(int idLibro, int idSocio, LocalDate inicio, LocalDate fin) throws SQLException {
        String sqlStock = "UPDATE libros SET num_ejemplares = num_ejemplares - 1 "
                + "WHERE id_libro = ? AND num_ejemplares > 0";
        String sqlPrestamo = "INSERT INTO prestamos (id_libro, id_socio, fecha_inicio, fecha_fin) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);   // empieza la transacción
            try (PreparedStatement psStock = con.prepareStatement(sqlStock);
                 PreparedStatement psPrestamo = con.prepareStatement(sqlPrestamo)) {

                psStock.setInt(1, idLibro);
                if (psStock.executeUpdate() == 0) {   // no existe el libro o no quedan ejemplares
                    con.rollback();
                    return false;
                }

                psPrestamo.setInt(1, idLibro);
                psPrestamo.setInt(2, idSocio);
                psPrestamo.setDate(3, Date.valueOf(inicio));
                psPrestamo.setDate(4, Date.valueOf(fin));
                psPrestamo.executeUpdate();

                con.commit();                          // confirma las dos operaciones
                return true;
            } catch (SQLException e) {
                con.rollback();                        // deshace todo si algo falla
                throw e;
            }
        }
    }
    // 1) Libros prestados actualmente
    public List<String> librosPrestados() throws SQLException {
        String sql = "SELECT l.titulo, s.nombre, s.apellidos, p.fecha_inicio, p.fecha_fin "
                + "FROM prestamos p "
                + "JOIN libros l ON p.id_libro = l.id_libro "
                + "JOIN socios s ON p.id_socio = s.id_socio "
                + "ORDER BY p.fecha_fin";
        List<String> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(rs.getString("titulo") + " -> " + rs.getString("nombre") + " "
                        + rs.getString("apellidos") + " (" + rs.getDate("fecha_inicio")
                        + " a " + rs.getDate("fecha_fin") + ")");
            }
        }
        return lista;
    }

    // 2) Número de libros prestados a un socio
    public int contarPrestamosSocio(int idSocio) throws SQLException {
        String sql = "SELECT COUNT(*) FROM prestamos WHERE id_socio = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idSocio);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();               // COUNT siempre devuelve una fila
                return rs.getInt(1);
            }
        }
    }

    // 3) Libros que han superado la fecha de fin de préstamo
    public List<String> librosVencidos() throws SQLException {
        String sql = "SELECT l.titulo, s.nombre, s.apellidos, p.fecha_fin "
                + "FROM prestamos p "
                + "JOIN libros l ON p.id_libro = l.id_libro "
                + "JOIN socios s ON p.id_socio = s.id_socio "
                + "WHERE p.fecha_fin < CURRENT_DATE";
        List<String> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(rs.getString("titulo") + " (debía devolverlo " + rs.getDate("fecha_fin")
                        + " " + rs.getString("nombre") + " " + rs.getString("apellidos") + ")");
            }
        }
        return lista;
    }

    // 4) Socios con libros que han superado la fecha de fin
    public List<String> sociosConRetraso() throws SQLException {
        String sql = "SELECT DISTINCT s.id_socio, s.nombre, s.apellidos, s.telefono "
                + "FROM socios s "
                + "JOIN prestamos p ON p.id_socio = s.id_socio "
                + "WHERE p.fecha_fin < CURRENT_DATE";
        List<String> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(rs.getInt("id_socio") + " | " + rs.getString("nombre") + " "
                        + rs.getString("apellidos") + " | " + rs.getString("telefono"));
            }
        }
        return lista;
    }
}