package org.example;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SocioDAO {

    public void insertar(Socio s) throws SQLException {
        String sql = "INSERT INTO socios (nombre, apellidos, edad, direccion, telefono) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getNombre());
            ps.setString(2, s.getApellidos());
            ps.setInt(3, s.getEdad());
            ps.setString(4, s.getDireccion());
            ps.setString(5, s.getTelefono());
            ps.executeUpdate();
        }
    }

    public int eliminar(int idSocio) throws SQLException {
        String sql = "DELETE FROM socios WHERE id_socio = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idSocio);
            return ps.executeUpdate();
        }
    }

    public int modificar(Socio s) throws SQLException {
        String sql = "UPDATE socios SET nombre = ?, apellidos = ?, edad = ?, "
                + "direccion = ?, telefono = ? WHERE id_socio = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getNombre());
            ps.setString(2, s.getApellidos());
            ps.setInt(3, s.getEdad());
            ps.setString(4, s.getDireccion());
            ps.setString(5, s.getTelefono());
            ps.setInt(6, s.getIdSocio());
            return ps.executeUpdate();
        }
    }
    public List<Socio> buscarPorNombre(String nombre) throws SQLException {
        return buscar("SELECT * FROM socios WHERE LOWER(nombre) LIKE LOWER(?)", nombre);
    }

    public List<Socio> buscarPorApellidos(String apellidos) throws SQLException {
        return buscar("SELECT * FROM socios WHERE LOWER(apellidos) LIKE LOWER(?)", apellidos);
    }

    private List<Socio> buscar(String sql, String valor) throws SQLException {
        List<Socio> lista = new ArrayList<>();
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + valor + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Socio s = new Socio();
                    s.setIdSocio(rs.getInt("id_socio"));
                    s.setNombre(rs.getString("nombre"));
                    s.setApellidos(rs.getString("apellidos"));
                    s.setEdad(rs.getInt("edad"));
                    s.setDireccion(rs.getString("direccion"));
                    s.setTelefono(rs.getString("telefono"));
                    lista.add(s);
                }
            }
        }
        return lista;
    }
}